<?php

require_once "lib.php";

echo "Informe um número: ";
$n = fgets(STDIN);

echo fatorial($n);