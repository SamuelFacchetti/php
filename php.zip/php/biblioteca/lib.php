<?php

function fatorial($n){
	$total = 1;
	for ($i=1; $i <= $n; $i++) { 
		$total *= $i;
	}

	return $total;
}
