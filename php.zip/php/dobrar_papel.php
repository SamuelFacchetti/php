<?php

echo "\nDigite o numero de vezes para dobrar uma folha de papel A4: ";
$vezes = fgets(STDIN);

// medidas em metros
$profundidade = 0.21;
$comprimento = 0.297;
$altura = 0.0001;

for ($i=0; $i < $vezes; $i++) {
	$altura *= 2;

	if ($i % 2 == 0) {
		$comprimento /= 2;
	} else {
		$profundidade /= 2;
	}
}

echo "\nQuantidade de dobras: ", $vezes;
echo "\nComprimento: ", $comprimento, " metros";
echo "\nAltura: ", $altura, " metros";
echo "\nProfundidade: ", $profundidade, " metros";

?>