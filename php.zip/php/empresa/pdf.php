<?php

require_once "fpdf/fpdf.php";

$pdf = new FPDF('P', 'mm', array(210,297));
$pdf->AddPage();

$pdf->SetFont('Arial','I','15');

$file = fopen('dados.csv','r');

$contar_linha = 0;

while (!feof($file)) {
	$linha = fgets($file);
	$conteudo = explode(',', $linha);
	$pdf->Cell(0,15,"Prontuario: ".$conteudo[0]." ".$conteudo[1]." - profissao: ".$conteudo[2],0,1,'L');

	$contar_linha++;

	if (($contar_linha == 17) and !feof($file)) {
		$pdf->AddPage();
		$contar_linha = 0;
	}
}

fclose($file);

$destino = "listas/".md5(time()).".pdf";

$pdf->Output($destino,'F');
