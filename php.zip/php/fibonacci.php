<?php

function fibonacci($n, $i){
	if ($i < 10){return fibonacci($n - 1, $i++) + fibonacci($n - 2, $i++);}
}

echo fibonacci(2, 0);

?>