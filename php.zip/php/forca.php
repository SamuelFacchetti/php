<?php

	function verificaLetra($letra, $palavra){
		$corretas = [];

		for ($i=0; $i < count($palavra); $i++) { 
			if (ord(strtolower($letra)) == ord(strtolower($palavra[$i]))) {
				$corretas[] = [$i, $palavra[$i]];
			}
		}

		if (count($corretas) > 0) { return $corretas; }
		else { return false; }
	}

	$lista = [
		"peixe",
		"gato",
		"cachorro",
		"hipopotamo",
		"arara",
		"tatu"
	];

	$palavra = str_split($lista[rand(0, count($lista) -1)]);
	$acertos = 0;
	$erros = 0;

	while (($acertos < count($palavra)) && ($erros < 5)) {
		echo "Digite uma letra: ";
		$valor = fgets(STDIN);

		if(verificaLetra($valor, $palavra)){
			$acertos += count(verificaLetra($valor, $palavra));
		} else {
			$erros++;
		}
	}

	if ($acertos == count($palavra)) { echo "\nParabéns, você ganhou!\n"; }
	else { echo "\nQue pena, você perdeu!\n"; }

