<?php

function ola($n = "Ola mundo") {
    echo $n;
}

ola();