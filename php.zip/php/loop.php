<?php

/*
$alfabeto = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];

for ($i=0; $i < count($alfabeto); $i++) { 
	echo $alfabeto[$i]."\n";
}

$matriz = [
	['a', 'b', 'c'],
	['a', 'b', 'c'],
	['a', 'b', 'c'],
];

for ($i=0; $i < count($matriz); $i++) { 
	for ($j = 0; $j < count($matriz[$i]); $j++) { 
		echo $matriz[$i][$j]."\t";
	}
	echo "\n";
}

*/

$matriz = [];

for ($i=0; $i < 26 ; $i++) { 
	for ($j=0; $j <= $i; $j++) { 
		$matriz[$i][$j] = chr($j+97);
	}
}

for ($i=0; $i < count($matriz); $i++) { 
	for ($j = 0; $j < count($matriz[$i]); $j++) { 
		echo $matriz[$i][$j]."\t";
	}
	echo "\n";
}
