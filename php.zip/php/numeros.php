<?php

echo "\nDigite um numero: ";
$numero1 = fgets(STDIN);

echo "\nDigite outro numero: ";
$numero2 = fgets(STDIN);

echo "\nSoma: ", ($numero1 + $numero2);
echo "\nSubtracao: ", ($numero1 - $numero2);
echo "\nMultiplicacao: ", ($numero1 * $numero2);
echo "\nDivisao: ", ($numero1 / $numero2);

?>