<?php

require_once "fpdf/fpdf.php";

$pdf = new FPDF('P','mm',array(210,297));

$usuario = fgets(STDIN);

$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(80);
$pdf->Cell(20,15,$usuario,0,1,'C');

$pdf->Output("F", "gerar.pdf");