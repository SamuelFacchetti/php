<?php

echo "0 - Pedra \t 1 - Papel \t 2 - Tesoura";

echo "\nJogador 1, informe sua escolha: ";
$jogador1 = fgets(STDIN);

echo "\nJogador 2, informe sua escolha: ";
$jogador2 = fgets(STDIN);

if ($jogador1 == $jogador2) { // PE X PE // PA X PA // TE X TE //
	echo "\nEmpate!";
} else {
	if ($jogador1 == 0) {
		if ($jogador2 == 2) {
			echo "Jogador 1 ganhou!";
		} else {
			echo "Jogador 2 ganhou!";
		}
	} elseif ($jogador1 == 2) {
		if ($jogador2 == 1) {
			echo "Jogador 1 ganhou!";
		} else {
			echo "Jogador 2 ganhou!";
		}
	} else { // jogador1 == 1
		if ($jogador2 == 0) {
			echo "Jogador 1 ganhou!";
		} else {
			echo "Jogador 2 ganhou!";
		}
		
	}
}
