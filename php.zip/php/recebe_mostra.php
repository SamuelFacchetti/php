<?php

echo "Digite algo: ";
$texto = fgets(STDIN);

echo "\nO que voce digitou foi: ", $texto;

?>