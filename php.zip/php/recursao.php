<?php

function recursivo($n){
	echo $n;
	return recursivo($n * 2);
}

recursivo(1);