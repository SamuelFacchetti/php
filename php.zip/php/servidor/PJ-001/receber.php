<?php

if ((isset($_GET["nome"])) or (isset($_POST["nome"])) ) {
	if (isset($_GET["nome"])) {
		if ($_GET["nome"] == "") { $nome = "Digite um nome na url"; }
		else { $nome = $_GET["nome"]; }

		if ($_GET["idade"] == "") { $idade = "Digite uma idade na url"; }
		else {$idade = $_GET["idade"];}
	} else {
		$nome = $_POST["nome"];
		$idade = $_POST["idade"];
	}

} else {
	$nome = "Não há nome informado";
	$idade = "Não há idade informada";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h3>Nome: <?=$nome?></h3>
	<h4>Idade: <?php $idade > 100 ? "Idade Inválida" : $idade; ?></h4>
	<br>
	<a href="formulario.php">Voltar</a>
</body>
</html>