<?php

$n1 = (float)readline("Insira um numero: ");

$n2 = (float)readline("Insira outro numero: ");

$resultado = $n1 + $n2;

echo "\nResultado da soma entre ".$n1." e ".$n2.": ".$resultado;

?>