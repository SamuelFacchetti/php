<?php

echo "Digite um numero de 1 a 10: ";
$n1 = fgets(STDIN);

$tentativas = 0;
do {
	$n2 = rand(0,10);
	$tentativas++;
} while ($n1 != $n2);

echo "O loop encerrou em $tentativas tentativas!";

?>