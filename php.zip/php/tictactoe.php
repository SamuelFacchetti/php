<?php

function verificar($posicao){
	switch ($posicao) {
		case 'A1':
			# code...
			break;
		
		default:
			# code...
			break;
	}
	return true;
}

function retornarIndice($coordenada){
	$letras = [
		"A" => 0,
		"B" => 1,
		"C" => 2
	];

	$numeros = [
		1 => 0,
		2 => 1,
		3 => 2
	];

	$posicao = str_split($coordenada);

	return [$letras[$posicao[0]], $numeros[$posicao[1]]];
}

$matriz = [
	["","",""],
	["","",""],
	["","",""]
];

echo "
	A1 \t | \t A2 \t | \t A3 \n
	B1 \t | \t B2 \t | \t B3 \n
	C1 \t | \t C2 \t | \t C3 \n
";

echo "Jogador 1, faça sua jogada: ";
$jogador1 = fgets(STDIN);

echo "Jogador 2, faça sua jogada: ";
$jogador2 = fgets(STDIN);

// $matriz[$linha][$coluna] = $valor;